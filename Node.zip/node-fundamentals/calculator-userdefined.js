const Calculator = require('./calculator');
var calc = new Calculator();
console.log(calc.add(5,6));
console.log(calc.multiply(5,6));