const app = require('../../app');

//Additional Features required for Testing can be added here
module.exports = app;