const Configs = {
    'MongoURI':'mongodb://localhost/SampleDB'
}
module.exports = Configs;