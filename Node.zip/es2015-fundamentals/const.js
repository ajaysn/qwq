const PI = 3.1413;
//PI = 5345; //We cannot change the value
console.log(PI);