var printNameAndCity = (name,city='Bengaluru')=>{
    console.log(`Name: ${name} City: ${city}`);
}

printNameAndCity('Karthik');
printNameAndCity('Karthik','Chennai');
